<?php

namespace App\Models;

use App\Http\Controllers\ParseController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Parse extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

}
