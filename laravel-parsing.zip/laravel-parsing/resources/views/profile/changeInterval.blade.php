<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Interval  
        </h2>
    </x-slot>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <form method="POST" action="/getdata">
            @csrf
            <div>
                <x-input-label for="interval" class="mt-3" :value="__('Interval of getting update')" />
                <x-text-input id="interval" class="block mt-1 w-full" type="text" name="interval" placeholder="Enter second for getting updates in this second" required/>
                
                <x-input-error :messages="$errors->get('email')" class="mt-2" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <x-primary-button class="ml-3">
                    Get data
                </x-primary-button>
            </div>
        </form>
    </div>
</x-app-layout>
