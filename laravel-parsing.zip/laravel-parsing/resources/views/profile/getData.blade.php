<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Informations    
        </h2>
    </x-slot>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="py-12 flex justify-between items-center">
            <div class="my-3">
                <p>New data:</p>
                <h4>Token: {{ $getNewData['cryptoToken'] }}</h4>
                <h4>Value in USD: {{ $getNewData['valueInDollar'] }} $</h4>
                <h4>Value in PEPE: {{ $getNewData['currentBalance'] }}</h4>
            </div>
            <div class="my-3">
                <p>Old data:</p>
                    @if($getOldaData == null)
                        <h4>It's the first time, that is why there're no old data</h4>
                     @else 
                        <h4>Token: {{ $getOldaData->tokenCrypto }}</h4>
                        <h4>Value in USD: {{ $getOldaData->value_dollar }} $</h4>
                        <h4>Value in PEPE: {{ $getOldaData->balance }}</h4>
                        <h4>Date of old data: {{ $getOldaData->updated_at }}</h4>
                    @endif
            </div>
        </div>
    </div>
    @if ($getOldaData == null)
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="py-12 flex justify-between items-center">
                <div class="my-3">
                    <p>Difference</p>
                    <h4>In USD: {{ $getNewData['valueInDollar'] - $getOldaData->value_dollar }} $</h4>
                    <h4>In PEPE: {{ $getNewData['currentBalance'] - $getOldaData->balance }}</h4>
                </div>

            </div>
        </div>
    @endif
</x-app-layout>
